ipython assign9.py
pdflatex report.tex
rm *.png
evince report.pdf
