ipython assign6.py
pdflatex report.tex
rm *.png
evince report.pdf
