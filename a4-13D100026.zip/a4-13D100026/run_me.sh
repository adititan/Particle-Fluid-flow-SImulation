ipython assign4.py
pdflatex report.tex
pdflatex report.tex
evince report.pdf

