ipython assign3.py
