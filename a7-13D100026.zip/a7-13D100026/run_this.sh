ipython a7.py
pdflatex report.tex
evince report.pdf
